#%%
""" Poll the Fink servers only once at a time """
from fink_client.consumer import AlertConsumer
from fink_client.configuration import load_credentials

from astropy.time import Time

import time
import tabulate
#%%
def poll_single_alert(myconfig, topics) -> None:
    """ Connect to and poll fink servers once.

    Parameters
    ----------
    myconfig: dic
        python dictionnary containing credentials
    topics: list of str
        List of string with topic names
    """
    maxtimeout = 36000

    # Instantiate a consumer
    consumer = AlertConsumer(topics, myconfig)

    # Poll the servers
    topic, alert, key = consumer.poll(maxtimeout)

    # Analyse output - we just print some values for example
    if topic is not None:
        utc = time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())
        table = [
            [
                Time(alert['candidate']['jd'], format='jd').iso,
                utc,
                topic,
                alert['objectId'],
                alert['cdsxmatch'],
                alert['candidate']['magpsf']
            ],
        ]
        headers = [
            'Emitted at (UTC)',
            'Received at (UTC)',
            'Topic',
            'objectId',
            'Simbad',
            'Magnitude'
        ]
        print(tabulate(table, headers, tablefmt="pretty"))
    else:
        print(
            'No alerts received in the last {} seconds'.format(
                maxtimeout
            )
        )

    # Close the connection to the servers
    consumer.close()

#%%
if __name__ == "__main__":
    """ Poll the servers only once at a time """

    # to fill
    myconfig = {
        'bootstrap.servers': '134.158.74.95:24499',
        'group.id': 'hyeonho_snia'
    }

    topics = ['fink_early_sn_candidates_ztf']

    poll_single_alert(myconfig, topics)
# %%
