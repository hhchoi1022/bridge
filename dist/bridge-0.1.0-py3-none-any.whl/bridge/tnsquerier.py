#%%
import os
import json
import time
import requests
from pathlib import Path
from collections import OrderedDict
from datetime import datetime
from astropy.table import Table
from astropy.io import ascii
import pandas as pd
import numpy as np
import astropy.units as u
from astropy.coordinates import SkyCoord
from astropy.table import vstack
from astropy.time import Time


class TNSQuerier:
    """
    A class for querying the TNS server and handling results.
    """

    def __init__(self, config_path = f'{Path(__file__).parent}/tnsquerier.config'):
        """
        Initialize the TNSQuerier class.

        Parameters:
            api_key (str): The API key for TNS.
            bot_id (str): The bot ID for TNS.
            bot_name (str): The bot name.
            user_id (str): User ID (if querying as a user).
            user_name (str): User name (if querying as a user).
        """
        self.config = self._read_config(config_path)
        self.api_key = self.config['api_key']
        self.bot_id = self.config['bot_id']
        self.bot_name = self.config['bot_name']

        self.base_url = "https://www.wis-tns.org"
        self.search_url = f"{self.base_url}/search"
        self.headers = {'User-Agent': self._set_tns_marker()}
        
    def _read_config(self, config_path):
        """
        Reads a config file and returns a dictionary.

        Parameters:
            config_path (str): Path to the config file.

        Returns:
            dict: Configuration options as key-value pairs.
        """
        with open(config_path, 'r') as f:
            config_dict = json.load(f)
        return config_dict

    def _set_tns_marker(self):
        """
        Set the TNS marker for API requests.

        Parameters:
            bot (bool): If True, use bot credentials. If False, use user credentials.

        Returns:
            str: TNS marker string.
        """
        return f'tns_marker{{"tns_id": "{self.bot_id}", "type": "bot", "name": "{self.bot_name}"}}'
    
    # function for searching TNS with specified url parameters
    def search_tns(self, url_parameters, 
                   alert_save_dir : str = None,
                   timeout_seconds : float = 600
                   ):
        #--------------------------------------------------------------------
        # extract keywords and values from url parameters
        url_parameters['format'] = 'csv'
        url_parameters['num_page'] = '100'
        keywords = list(url_parameters.keys())
        values = list(url_parameters.values())
        #--------------------------------------------------------------------
        # flag for checking if url is with correct keywords
        wrong_url = False
        # check if keywords are correct
        for i in range(len(keywords)):
            if keywords[i] not in self._all_url_params:
                print ("Unknown url keyword '"+keywords[i]+"'\n")
                wrong_url = True
        if wrong_url == True:
            print ("TNS search url is not in the correct format.\n")
        #--------------------------------------------------------------------
        # else, if everything is correct
        else:
            # current date and time
            current_datetime = datetime.now()
            current_date_time = current_datetime.strftime("%Y%m%d_%H%M%S")
            # current working directory
            cwd = os.getcwd()        
            extension = ".txt"
            tns_search_file = "tns_search_data_" + current_date_time + extension
            if alert_save_dir is None:
                alert_save_dir = Path(__file__).parent / self.config['alert_save_dir']
            tns_search_file_path = os.path.join(cwd, alert_save_dir, tns_search_file)       
            if not os.path.exists(os.path.join(cwd, alert_save_dir)):
                os.makedirs(os.path.join(cwd, alert_save_dir))     
            #--------------------------------------------------------------------
            # build TNS search url
            url_par = ['&' + x + '=' + y for x, y in zip(keywords, values)]
            tns_search_url = self.search_url + '?' + "".join(url_par)
            #--------------------------------------------------------------------
            # page number
            page_num = 0
            # searched data
            searched_data = []
            # go trough every page
            start_time = time.time()
            while time.time() - start_time < timeout_seconds:
                # url for download
                url = tns_search_url + "&page=" + str(page_num)        
                headers = self.headers
                # downloading file using request module
                response = requests.post(url, headers=headers, data = {'api_key': self.api_key}, stream=True)
                # chek if response status code is not 200, or if returned data is empty
                if (response.status_code != 200) or (len((response.text).splitlines()) <= 1):
                    if response.status_code != 200:
                        print ("Sending download search request for page num " + str(page_num + 1) + "...")
                        self._print_response(response, page_num + 1)
                    break            
                print ("Sending download search request for page num " + str(page_num + 1) + "...")
                # print status code of the response
                self._print_response(response, page_num + 1)
                # get data
                data = (response.text).splitlines()
                # add to searched data
                if page_num == 0:
                    searched_data.append(data)
                else:
                    searched_data.append(data[1 : ])
                # check reset time
                reset = self._get_reset_time(response)
                if reset != None:
                    # Sleeping for reset + 1 sec
                    print("\nSleep for " + str(reset + 1) + " sec and then continue...\n") 
                    time.sleep(reset + 1)
                # increase page num
                page_num = page_num + 1
            #--------------------------------------------------------------------
            # if there is searched data, write to file
            if searched_data != []:            
                searched_data = [j for i in searched_data for j in i]            
                #if merge_to_single_file == 1:
                f = open(tns_search_file_path, 'w')
                for el in searched_data:
                    f.write(el + '\n')
                f.close()
                if len(searched_data) > 2:
                    print ("\nTNS searched data returned " + str(len(searched_data) - 1) + " rows. File '" + \
                        tns_search_file + "' is successfully created.\n")
                    return tns_search_file_path
                else: 
                    print ("\nTNS searched data returned 1 row. File '" + tns_search_file + "' is successfully created.\n")            
                    return tns_search_file_path
            else:
                print ("TNS searched data returned empty list. No file(s) created.\n")
            

    def update_alerthisotry(self, new_alert_path, historyfile_path= None):
        # ?? ??
        new_df = pd.read_csv(new_alert_path)
        
        if historyfile_path == None:
            historyfile_path = Path(__file__).parent / self.config['historyfile_path']
        try:
            hist_df = pd.read_csv(historyfile_path)
        except FileNotFoundError:
            new_df.to_csv(historyfile_path, index=False)
            print(f"Created new history file: {historyfile_path}")
            return

        # ?? (?? ??)
        merged_df = pd.concat([hist_df, new_df], ignore_index=True)
        merged_df = merged_df.drop_duplicates(subset=['ID'], keep='first')

        # ??
        merged_df = merged_df.sort_values('ID', ascending=False)

        merged_df.to_csv(historyfile_path, index=False)
        print(f"Updated history file: {historyfile_path}")



    def _response_status(self, response):
        # external http errors
        ext_http_errors       = [403, 500, 503]
        err_msg               = ["Forbidden", "Internal Server Error: Something is broken", "Service Unavailable"]
        def is_string_json(string):
            try:
                json_object = json.loads(string)
            except Exception:
                return False
            return json_object

        json_string = is_string_json(response.text)
        if json_string != False:
            status = "[ " + str(json_string['id_code']) + " - '" + json_string['id_message'] + "' ]"
        else:
            status_code = response.status_code
            if status_code == 200:
                status_msg = 'OK'
            elif status_code in ext_http_errors:
                status_msg = err_msg[ext_http_errors.index(status_code)]
            else:
                status_msg = 'Undocumented error'
            status = "[ " + str(status_code) + " - '" + status_msg + "' ]"
        return status

    def _print_response(self, response, page_num):
        status = self._response_status(response)
        if response.status_code == 200:     
            stats = 'Page number ' + str(page_num) + ' | return code: ' + status
        
        else:       
            stats = 'Page number ' + str(page_num) + ' | return code: ' + status        
        print (stats)
                    
    def _send_request(self, parameters):
        """
        Send a POST request to TNS.

        Parameters:
            parameters (dict): Request parameters.

        Returns:
            Response: The HTTP response object.
        """
        search_data = {"api_key": self.api_key, "data": json.dumps(OrderedDict(parameters))}
        return requests.post(self.search_url, headers=self.headers, data=search_data)

    def _get_reset_time(self, response):
        """
        Get the rate-limit reset time from the response headers.

        Parameters:
            response (Response): The HTTP response object.

        Returns:
            int or None: Reset time in seconds, or None if no reset is required.
        """
        # If any of the '...-remaining' values is zero, return the reset time
        for name in response.headers:
            value = response.headers.get(name)
            if name.endswith('-remaining') and value == '0':
                return int(response.headers.get(name.replace('remaining', 'reset')))
        return None     
    
    def _get_skycoord(self,
                     ra : str or float,
                     dec: str or float,
                     ra_unit : str = 'hourangle',
                     dec_unit : str = 'deg'
                     ):
        """
        Parameters
        ==========
        ra : str | float = Right Ascension, if str, it should be in hms format (e.g., "10:20:30"), if float, it should be in decimal degrees
        dec : str | float = Declination, if str, it should be in dms format (e.g., "+20:30:40"), if float, it should be in decimal degrees
        
        Return
        ======
        coord : SkyCoord = SkyCoord object
        """
        
        u_ra = u.hourangle if ra_unit == 'hourangle' else u.deg
        u_dec = u.deg if dec_unit == 'deg' else u.deg
        coord = SkyCoord(ra, dec, unit=(u_ra, u_dec))
        return coord
            
    @property
    def _all_url_params(self):
        URL_PARAMETERS   = ["discovered_period_value", "discovered_period_units", "unclassified_at", "classified_sne", "include_frb",
                            "name", "name_like", "isTNS_AT", "public", "ra", "decl", "radius", "coords_unit", "reporting_groupid[]",
                            "groupid", "classifier_groupid", "objtype", "at_type", "discovery_date_start",
                            "discovery_date_end",  "discovery_mag_min", "discovery_mag_max", "internal_name", "discoverer", "classifier",
                            "spectra_count", "redshift_min", "redshift_max", "hostname", "ext_catid", "ra_range_min", "ra_range_max",
                            "decl_range_min", "decl_range_max", "discovery_instrument[]", "classification_instrument[]",
                            "associated_groups[]", "official_discovery", "official_classification", "at_rep_remarks", "class_rep_remarks",
                            "frb_repeat", "frb_repeater_of_objid", "frb_measured_redshift", "frb_dm_range_min", "frb_dm_range_max",
                            "frb_rm_range_min", "frb_rm_range_max", "frb_snr_range_min", "frb_snr_range_max", "frb_flux_range_min",
                            "frb_flux_range_max", "format", "num_page"]
        return URL_PARAMETERS
    
    
#%%
# Example usag
if __name__ == "__main__":
    
    # if len(sys.argv) != 2:
    #     print("Usage: python tnsqurier.py <configfile>")
    #     sys.exit(1)

    # config_file_path = sys.argv[1]
    config = read_config('./tnsquerier.config')

    # Print the configuration as a dictionary
    print("Loaded configuration:", config)
    
    now = Time.now() 
    start_date = now - float(config['date_duration'])*u.day
    start_date = now - 1 * u.day
    # Example TNS parameters
    self = TNSQuerier(config['api_key'], config['bot_id'], config['bot_name'])
    url_parameters = {'internal_name': 'ASASSN-14ae'}
    file = self.search_tns(url_parameters = url_parameters, alert_save_dir = config['alert_save_dir'])
    
    # date_start = "2023-05-01"
    # date_end = "2025-08-13"

    # for date in pd.date_range(date_start, date_end):
    #     print('Start searching for date: ', date.strftime("%Y-%m-%d"))
    #     url_parameters = {"discovery_date_start": date.strftime("%Y-%m-%d"), "decl_range_max": "20"}
    #     alert_save_dir = config['alert_save_dir']
    #     historyfile_path = config['historyfile_path']
    #     print(alert_save_dir, historyfile_path)
    #     file_ = self.search_tns(url_parameters = url_parameters, alert_save_dir = config['alert_save_dir'])
    #     file2_ = self.update_alerthisotry(file_, historyfile_path = config['historyfile_path'])
    #     time.sleep(10)

# %%
