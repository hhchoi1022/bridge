#%%
from alerce.core import Alerce
from astropy.time import Time
alerce = Alerce()
#%%
dataframe = alerce.query_objects()
#%%
params = {
   "classifier": "stamp_classifier",
   "class_name": "SN",
   "probability": 0.7,
   'order_by': 'firstmjd',
   'order_mode': 'DESC',
}
objects = alerce.query_objects(**params)
#%%
classifiers = alerce.query_classifiers()
#%%
objects
# %%
