"""
ALERCE Alert Receiver Package

A modular system for receiving and processing ALERCE astronomical alerts.
"""

from .core import AlerceClient
from .alert_processor import AlertProcessor
from .data_models import AlertConfig, AlertObject
from .config_manager import ConfigManager
from .receiver import AlerceAlertReceiver

__version__ = "0.1.0"
__author__ = "Your Name"

__all__ = [
    "AlerceClient",
    "AlertProcessor", 
    "AlertConfig",
    "AlertObject",
    "ConfigManager",
    "AlerceAlertReceiver"
]