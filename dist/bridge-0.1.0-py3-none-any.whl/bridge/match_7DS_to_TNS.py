#%%
import pandas as pd
import numpy as np
from astropy.coordinates import SkyCoord
import astropy.units as u
from tqdm import tqdm

# 1. Load and filter transients
targets = pd.read_csv('targets.ascii')
import pandas as pd
import matplotlib.pyplot as plt

import numpy as np
import matplotlib.pyplot as plt

import pandas as pd

def _prepare_counts(series, top_n=None, min_count=None, other_label="Other"):
    s = (series.astype(str)
               .str.strip()
               .replace({"nan": np.nan, "None": np.nan, "" : np.nan}))
    s = s.dropna()
    counts = s.value_counts()

    if top_n is not None:
        top = counts.iloc[:top_n]
        rest_sum = counts.iloc[top_n:].sum()
    elif min_count is not None:
        top = counts[counts >= min_count]
        rest_sum = counts[counts < min_count].sum()
    else:
        top = counts
        rest_sum = 0

    if rest_sum > 0:
        top = pd.concat([top, pd.Series({other_label: rest_sum})])
    return top
def plot_objtype_barh(series, top_n=10, min_count=None, other_label="Other",
                      title="Object Types", figsize=(8, max(4, 0.45*10))):
    counts = _prepare_counts(series, top_n=top_n, min_count=min_count, other_label=other_label)
    total = counts.sum()
    frac = counts / total * 100.0

    fig, ax = plt.subplots(figsize=(figsize[0], max(figsize[1], 0.4*len(counts)+1)))
    y = np.arange(len(counts))[::-1]  # largest at top
    bars = ax.barh(y, counts.values)

    # color map for nicer look
    cmap = plt.cm.get_cmap("tab20")
    for i, b in enumerate(bars):
        b.set_facecolor(cmap(i % 20))

    ax.set_yticks(y, counts.index)
    ax.set_xlabel("Count")
    ax.set_title(title)

    # annotate counts and percentages
    for i, (c, p) in enumerate(zip(counts.values, frac.values)):
        ax.text(c + max(counts.values)*0.01, y[i],
                f"{c}  ({p:.1f}%)", va="center")

    plt.tight_layout()
    return fig, ax

def plot_objtype_donut(series, top_n=8, min_count=None, other_label="Other",
                       title="Object Types", figsize=(7,7)):
    counts = _prepare_counts(series, top_n=top_n, min_count=min_count, other_label=other_label)
    total = counts.sum()
    labels = counts.index.tolist()
    sizes = counts.values

    fig, ax = plt.subplots(figsize=figsize)
    wedges, texts, autotexts = ax.pie(
        sizes,
        labels=None,  # we'll make a neat legend instead
        autopct=lambda p: f"{p:.1f}%" if p >= 3 else "",
        pctdistance=0.8,
        startangle=90,
        wedgeprops=dict(width=0.35)  # donut
    )
    ax.set_title(title)

    # consistent colors
    cmap = plt.cm.get_cmap("tab20")
    for i, w in enumerate(wedges):
        w.set_facecolor(cmap(i % 20))

    # legend with counts
    legend_labels = [f"# of {lab} : {cnt} ({cnt/total*100:.1f}%)"
                     for lab, cnt in zip(labels, sizes)]
    ax.legend(wedges, legend_labels, title="Types", loc="center left", bbox_to_anchor=(1, 0.5))
    plt.tight_layout()
    return fig, ax
series = targets['Obj. Type']  # or targets['obj_type']

# 1) Horizontal bar: keep top 12, fold the rest into "Other"
plot_objtype_barh(series, top_n=12, other_label="Other", title="Object Types (Top 12)")

# 2) Donut: show top 8 only; tiny categories get folded into Other
plot_objtype_donut(series, top_n=8, other_label="Other", title="Object Types")
plt.show()
#%%


# ??: Discovery Mag ? 18
targets = targets[targets['Discovery Mag/Flux'] <= 19]

# ?? ??
targets['Discovery Date (UT)'] = pd.to_datetime(targets['Discovery Date (UT)'])

# 2. Load image metadata
images = pd.read_csv('./7DS/RIS_single_250721.csv')

# ?? ??
images['date-obs'] = pd.to_datetime(images['date-obs'])

# SkyCoord ??: ??? ?? ??
image_coords = SkyCoord(ra=images['ra'].values * u.deg,
                        dec=images['dec'].values * u.deg)

# 3. ?? ????
time_window_min = pd.Timedelta(days=3)     # ?? ? 30? ??
time_window_max = pd.Timedelta(days=30)     # ?? ? 30? ??
spatial_tol = 0.5 * u.deg               # ?????? 0.3? ??
#%%
# 4. ?? ??
matched_rows = []

for i, row in tqdm(targets.iterrows(), total=len(targets)):
    target_time = row['Discovery Date (UT)']
    time_start = target_time - time_window_min
    time_end = target_time + time_window_max

    # ?? ??: ?? ???? +30?
    time_mask = (images['date-obs'] >= time_start) & (images['date-obs'] <= time_end)
    if not time_mask.any():
        continue

    # RA, DEC ??
    try:
        target_coord = SkyCoord(ra=row['RA'], dec=row['DEC'], unit=(u.hourangle, u.deg))
    except Exception as e:
        continue  # ?? ?? ? ????

    selected_images = images[time_mask].copy()
    selected_coords = image_coords[time_mask.values]

    # ?? ??
    sep = target_coord.separation(selected_coords)
    spatial_mask = sep < spatial_tol

    if not spatial_mask.any():
        continue

    final_matches = selected_images[spatial_mask]

    for j, (idx, match_row) in enumerate(final_matches.iterrows()):
        matched_rows.append({
            'target_id': row['ID'],
            'target_name': row['Name'],
            'target_type': row['Obj. Type'],
            'target_ra': row['RA'],
            'target_dec': row['DEC'],
            'target_date': target_time,
            'target_mag': row['Discovery Mag/Flux'],
            'target_filter': row['Discovery Filter'],
            'matched_file': match_row['file'],
            'matched_date': match_row['date-obs'],
            'matched_ra': match_row['ra'],
            'matched_dec': match_row['dec'],
            'matched_tile': match_row['object'],
            'sep_arcsec': sep[spatial_mask].arcsec[j],  # ? ???: ??? ???? ??
            'time_delta': (match_row['date-obs'] - target_time).total_seconds() / 3600.0 / 24
        })

# 5. ?? ??
matched_df = pd.DataFrame(matched_rows)
matched_df.to_csv('matched_images.csv', index=False)
print(f'Matched {len(matched_df)} image(s) saved to matched_images.csv')

# %%
from astropy.table import Table
matched_tbl = Table.from_pandas(matched_df)
# %%
import matplotlib.pyplot as plt
plt.hist(matched_tbl['target_mag'], bins=20)
# %%
matched_tbl.write('matched_images.fits', format = 'ascii.fixed_width', overwrite=True)
# %%
tbl = matched_tbl[matched_tbl['target_mag'] < 17]
tbl.write('matched_images_bright.fits', format = 'ascii.fixed_width', overwrite=True)
# %%
matched_df_single = matched_df.drop_duplicates(subset=['target_name'])
series = matched_df_single['target_type']  # or targets['obj_type']

# 1) Horizontal bar: keep top 12, fold the rest into "Other"
plot_objtype_barh(series, top_n=12, other_label="Other", title="Object Types (Top 12)")

# 2) Donut: show top 8 only; tiny categories get folded into Other
plot_objtype_donut(series, top_n=8, other_label="Other", title="Object Types")
plt.show()

# %%
